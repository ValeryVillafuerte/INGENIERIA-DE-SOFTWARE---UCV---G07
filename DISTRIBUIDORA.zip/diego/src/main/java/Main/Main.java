package Main;
import Vistas.*;
import Modelo.ClienteDAO;
import Modelo.ClienteDTO;
import Controlador.ClienteControl;
import Vistas.frmCliente;
import Vistas.frmActualizarCliente;
import Vistas.frmHistorialCliente;

import Modelo.ProductoDAO;
import Modelo.ProductoDTO;
import Controlador.ProductoControl;

import Vistas.frmProductos;
import Vistas.frmProdArmarCarrito;
import Vistas.frmProdPedido;

import Modelo.PagoDAO;
import Modelo.PagoDTO;
import Controlador.PagoControl;
import Vistas.frmPago;
import Vistas.frmPagoComprobante;

public class Main {

    public static void main(String[] args) {
       
        frmCliente frmcliente = new frmCliente();
        frmActualizarCliente frmActCl = new frmActualizarCliente();
        frmcliente.setVisible(true);
        frmHistorialCliente frmHCl = new frmHistorialCliente();
        ClienteDAO CDAO = new ClienteDAO();
        ClienteDTO CDTO = new ClienteDTO();
        
        ClienteControl CC = new ClienteControl(CDAO, CDTO, frmcliente,frmActCl,frmHCl);
        
        frmProductos frmproductos = new frmProductos();
        frmProdArmarCarrito frmACarrito = frmProdArmarCarrito();
        frmproductos.setVisible(true);
        frmProdPedido frmPedido = frmProdPedido();
        ProductoDAO PDAO = new ProductoDAO();
        ProductoDTO PDTO = new ProductoDTO();
        
        ProductoControl PC = new ProductoControl(PDAO, PDTO, frmproductos, frmACarrito, frmPedido);
        
        frmPago frmpago = new frmPago();
        frmPagoComprobante frmcomprobante = new frmPagoComprobante();
        frmpago.setVisible(true);
        PagoDAO PADAO = new PagoDAO();
        PagoDTO PADTO = new PagoDTO();
        
        PagoControl PAC = new PagoControl(PADAO, PADTO, frmpago, frmcomprobante);
    }

}
