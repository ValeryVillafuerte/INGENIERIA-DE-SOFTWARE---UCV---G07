package Controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import Modelo.ClienteDAO;
import Modelo.ClienteDTO;
import Vistas.frmCliente;
import Vistas.frmActualizarCliente;
import Vistas.frmHistorialCliente;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ClienteControl implements ActionListener {
    private ClienteDAO CDAO;
    private ClienteDTO CDTO;
    private frmCliente frmcliente;
    private frmActualizarCliente frmActCl;
    private frmHistorialCliente frmHCl;
    
    public ClienteControl(ClienteDAO CDAO, ClienteDTO CDTO, 
            frmCliente frmcliente,frmActualizarCliente frmActCl,frmHistorialCliente frmHCl){
        this.CDAO = CDAO;
        this.CDTO = CDTO;
        this.frmcliente = frmcliente;
        this.frmActCl = frmActCl;     
        this.frmHCl = frmHCl;
        this.frmActCl.btnBuscarC.addActionListener(this);
        this.frmActCl.btnLimpiarMCliente.addActionListener(this); 
        this.frmActCl.btnCancelarMCliente.addActionListener(this);
        this.frmActCl.btnModificarAceptar.addActionListener(this);
        this.frmcliente.btnAgregar.addActionListener(this);
        this.frmcliente.btnLimpiarCliente.addActionListener(this);
        this.frmcliente.btnCancelarRCliente.addActionListener(this); 
        this.frmHCl.btnBuscarHistorialCliente.addActionListener(this);
        this.frmHCl.btnLimpiarHistorialCliente.addActionListener(this);
        this.frmHCl.btnCancelarHistorialCliente.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()== frmcliente.btnAgregar)
        {
            CDTO.setID_cliente(frmcliente.txtIDCliente.getText());
            CDTO.setNombreC(frmcliente.txtnombreC.getText());
            CDTO.setDni(frmcliente.txtDNIC.getText());
            CDTO.setTelefonoM(frmcliente.txtTelefonoM.getText());
            CDTO.setCorreo(frmcliente.txtcorreo.getText());
            CDTO.setDireccion(frmcliente.txtdireccion.getText());
            if(CDAO.grabarCliente(CDTO)){
                JOptionPane.showMessageDialog(null, "CLIENTE REGISTRADO");
                limpiarRegistroCliente();
                frmActCl.setVisible(true);
                frmcliente.setVisible(false);
            }else{
                JOptionPane.showMessageDialog(null, "ERROR AL REGISTRAR");
            }
        }
        if(e.getSource()== frmActCl.btnBuscarC)
        {
            String idCliente = frmActCl.txtBuscarDNIC.getText();
            ClienteDTO cliente = CDAO.buscarClientePorID(idCliente);
    
            if (cliente != null) {
                frmActCl.txtBuscarNombre.setText(cliente.getNombreC());
                frmActCl.txtBuscarDNI2C.setText(cliente.getDni());
                frmActCl.txtBuscarTelefono.setText(cliente.getTelefonoM());
                frmActCl.txtBuscarcorreo.setText(cliente.getCorreo());
                frmActCl.txtBuscardireccion.setText(cliente.getDireccion());
            } else {
                JOptionPane.showMessageDialog(null, "CLIENTE NO ENCONTRADO");
            }
        }
        if (e.getSource() == frmActCl.btnModificarAceptar) 
        {
            CDTO.setNombreC(frmActCl.txtBuscarNombre.getText());
            CDTO.setDni(frmActCl.txtBuscarDNI2C.getText());
            CDTO.setTelefonoM(frmActCl.txtBuscarTelefono.getText());
            CDTO.setCorreo(frmActCl.txtBuscarcorreo.getText());
            CDTO.setDireccion(frmActCl.txtBuscardireccion.getText());

            if (CDAO.actualizarCliente(CDTO)) {
                JOptionPane.showMessageDialog(null, "CLIENTE ACTUALIZADO");
                frmHCl.setVisible(true);
                 frmActCl.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "ERROR AL ACTUALIZAR");
            }
        }
        if (e.getSource() == frmHCl.btnBuscarHistorialCliente) 
        {
            String idCliente = frmHCl.txtIDClienteHistorial.getText();
            List<ClienteDTO> historial = CDAO.buscarHistorialCliente(idCliente);

            DefaultTableModel model = (DefaultTableModel) frmHCl.HistorialTabla.getModel();
            model.setRowCount(0); // Limpiar la tabla

            for (ClienteDTO cliente : historial) {
                model.addRow(new Object[]{
                    cliente.getID_cliente(),
                    cliente.getNombreC(),
                    cliente.getDni(),
                    cliente.getTelefonoM(),
                    cliente.getCorreo(),
                    cliente.getDireccion()
                });
            }

            if (historial.isEmpty()) {
                JOptionPane.showMessageDialog(null, "NO SE ENCONTRÓ HISTORIAL PARA EL CLIENTE");
            }
        }
         if (e.getSource() == frmHCl.btnLimpiarHistorialCliente) 
        {
             DefaultTableModel model = (DefaultTableModel) frmHCl.HistorialTabla.getModel();
            model.setRowCount(0); // Limpiar la tabla
        }
          if (e.getSource() == frmHCl.btnCancelarHistorialCliente) 
        {
            frmHCl.dispose();
        }

        if(e.getSource()== frmcliente.btnLimpiarCliente)
        {
            limpiarRegistroCliente();
        }
        if(e.getSource()== frmActCl.btnLimpiarMCliente)
        {
            limpiarModificarCliente();
        }
         if(e.getSource()== frmcliente.btnCancelarRCliente)
        {
            frmcliente.dispose();
        }
          if(e.getSource()== frmActCl.btnCancelarMCliente)
        {
            frmActCl.dispose();
        }
    }
    public void limpiarRegistroCliente()
    {
       frmcliente.txtIDCliente.setText(null); 
       frmcliente.txtnombreC.setText(null);
       frmcliente.txtDNIC.setText(null);
       frmcliente.txtTelefonoM.setText(null);
       frmcliente.txtcorreo.setText(null);       
       frmcliente.txtdireccion.setText(null);
    }
    public void limpiarModificarCliente()
    {
       frmActCl.txtBuscarDNIC.setText(null); 
       frmActCl.txtBuscarNombre.setText(null);
       frmActCl.txtBuscarDNI2C.setText(null);
       frmActCl.txtBuscarTelefono.setText(null);
       frmActCl.txtBuscarcorreo.setText(null);
       frmActCl.txtBuscardireccion.setText(null);
    }
    
}

