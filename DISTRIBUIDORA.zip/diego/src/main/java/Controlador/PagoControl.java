package Controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import Modelo.ClienteDAO;
import Modelo.ClienteDTO;
import Vistas.frmCliente;
import Vistas.frmActualizarCliente;
import Vistas.frmHistorialCliente;
import Modelo.ProductoDAO;
import Modelo.ProductoDTO;
import Vistas.frmProductos;
import Vistas.frmProdArmarCarrito;
import Vistas.frmProdPedido;
import Modelo.PagoDAO;
import Modelo.PagoDTO;
import Vistas.frmPago;
import Vistas.frmPagoComprobante;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class PagoControl implements ActionListener {
    private PagoDAO PADAO;
    private PagoDTO PADTO;
    private frmPago frmpago;
    private frmPagoComprobante frmcomprobante;
    
    public PagoControl(PagoDAO PADAO, PagoDTO PADTO, frmPago frmpago, frmPagoComprobante frmcomprobante){
        this.PADAO = PADAO;
        this.PADTO = PADTO;
        this.frmpago = frmpago;
        this.frmcomprobante = frmcomprobante;
        
        this.frmpago.btnActualizarPago.addActionListener(this);
        this.frmpago.btnRealizarPago.addActionListener(this);
        this.frmpago.btnLimpiarPago.addActionListener(this);
        this.frmpago.btnCancelarPago.addActionListener(this);
        
        this.frmcomprobante.btnBuscarPago.addActionListener(this);
        this.frmcomprobante.btnSalirComprobante.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==frmpago.btnRealizarPago){
            PADTO.setID_cliente(frmpago.txtBuscarDNI.getText());
            PADTO.setMedioP(frmpago.txtmedio.getText());
            if(PADAO.grabarPago(PADTO)){
            JOptionPane.showMessageDialog(null, "PAGO REGISTRADO");
                limpiarRegistroPago();
                frmcomprobante.setVisible(true);
                frmpago.setVisible(false);
            }else{
                JOptionPane.showMessageDialog(null, "ERROR AL REGISTRAR EL PAGO");
            }
        }
        if(e.getSource() == frmcomprobante.btnBuscarPago){
            String idCliente = frmcomprobante.txtBuscarDNI.getText();
            PagoDTO pago = PADAO.buscarPagoPorID(idCliente);
            
            if(pago != null){
                frmcomprobante.txtBuscarDNI.setText(pago.getDni());
            } else {
                JOptionPane.showMessageDialog(null, "PAGO NO ENCONTRADO");
            }
        }
        if(e.getSource()== frmpago.btnRealizarPago){
            PADTO.setDni(frmpago.txtBuscarDNI.getText());
            String idCliente = frmpago.txtBuscarDNI.getText();
            List<PagoDTO> pagos = PADAO.buscarComprobante(idCliente);
            
            DefaultTableModel model =(DefaultTableModel) frmpago.PagoTabla.getModel();
            model.setRowCount(0);
            
            for(PagoDTO pago : pagos){
                model.addRow(new Object[]{
                pago.getDni(),
                pago.getNombreC(),
                pago.getNombreP(),
                pago.getMedioP(),
                pago.getUnidad(),
                pago.getPrecio(),
                pago.getUnidad()
            });
            }
        }
        if(e.getSource() == frmcomprobante.btnFinalizarPago){
            PADTO.setDni(frmcomprobante.txtBuscarDNI.getText());
            String idCliente = frmcomprobante.txtBuscarDNI.getText();
            List<PagoDTO> comprobante = PADAO.buscarComprobante(idCliente);
            
            DefaultTableModel model =(DefaultTableModel) frmcomprobante.ComprobanteTabla.getModel();
            model.setRowCount(0);
            
            for(PagoDTO pago : comprobante){
                model.addRow(new Object[]{
                pago.getDni(),
                pago.getNombreC(),
                pago.getNombreP(),
                pago.getMedioP(),
                pago.getUnidad(),
                pago.getPrecio(),
                pago.getUnidad()
            });
            }
        }
        if(e.getSource() == frmcomprobante.btnBuscarComprobante){
            String idCliente = frmcomprobante.txtBuscarDNI.getText();
            List<PagoDTO> comprobante = PADAO.buscarComprobante(idCliente);
            
            DefaultTableModel model =(DefaultTableModel) frmcomprobante.ComprobanteTabla.getModel();
            model.setRowCount(0);
            
            for(PagoDTO pago : comprobante){
                model.addRow(new Object[]{
                pago.getDni(),
                pago.getNombreC(),
                pago.getNombreP(),
                pago.getMedioP(),
                pago.getUnidad(),
                pago.getPrecio(),
                pago.getUnidad()
            });
            }
            if(comprobante.isEmpty()){
                JOptionPane.showMessageDialog(null, "NO SE ENCONTRÓ COMPROBANTE PARA EL CLIENTE");
            }
        }
        if(e.getSource() == frmcomprobante.btnSalirComprobante){
            frmcomprobante.dispose();
        }
        if(e.getSource() == frmpago.btnLimpiarPago){
            limpiarRegistroPago();
        }
        if(e.getSource() == frmpago.btnCancelarPago){
            frmpago.dispose();
        }
    }
    public void limpiarRegistroPago(){
        frmpago.txtBuscarDNI.setText(null);
        frmpago.txtmedio.setText(null);
    }  
}
