
package Controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import Modelo.ProductoDAO;
import Modelo.ProductoDTO;
import Vistas.frmProductos;
import Vistas.frmProdArmarCarrito;
import Vistas.frmProdPedido;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class ProductoControl implements ActionListener {
    private ProductoDAO PDAO; 
    private ProductoDTO PDTO;
    private frmProductos frmproductos;
    private frmProdArmarCarrito frmACarrito;
    private frmProdPedido frmPedido;
    
    public ProductoControl(ProductoDAO PDAO, ProductoDTO PDTO, frmProductos frmproductos,
            frmProdArmarCarrito frmACarrito, frmProdPedido frmPedido){
        this.PDAO = PDAO;
        this.PDTO = PDTO; 
        this.frmproductos = frmproductos;
        this.frmACarrito = frmACarrito;
        this.frmPedido = frmPedido; 
        
        this.frmACarrito.btnBuscarCarrito.addActionListener(this);
        this.frmACarrito.btnLimpiarCarrito.addActionListener(this);
        this.frmACarrito.btnCancelarCarrito.addActionListener(this);
        this.frmACarrito.btnAgregadoCarrito.addActionListener(this);
        
        this.frmproductos.btnAgregarProducto.addActionListener(this);
        this.frmproductos.btnLimpiarProducto.addActionListener(this);
        this.frmproductos.btnCancelarProducto.addActionListener(this);
        
        this.frmPedido.btnBuscarPedido.addActionListener(this);
        this.frmPedido.btnCancelarPedido.addActionListener(this);
        this.frmPedido.btnAceptarPedido.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()== frmproductos.btnAgregarProducto){
            PDTO.setID_producto(frmproductos.txtIDproducto.getText());
            PDTO.setDni(frmproductos.txtDNIP.getText());
            PDTO.setNombreP(frmproductos.cboNombreP.getSelectedItem().toString());
            PDTO.setMarca(frmproductos.cbomarca.getSelectedItem().toString());
            PDTO.setUnidad(frmproductos.txtUnidad.getText()); 
            PDTO.setPrecio(frmproductos.cboPrecio.getSelectedItem().toString());
            PDTO.setFechaPedido(frmproductos.txtfechaPedido.getText());
            PDTO.setFechaEntrega(frmproductos.txtfechaEntrega.getText());
            if(PDAO.grabarProductos(PDTO)){
                JOptionPane.showMessageDialog(null, "PRODUCTO REGISTRADO");
            } else {
                JOptionPane.showMessageDialog(null, "ERROR AL REGISTRAR EL PRODUCTO");
            }
        }
        if(e.getSource()== frmACarrito.btnBuscarCarrito){
            try {
                String idProducto = frmACarrito.txtBuscarDNIP.getText();
                ProductoDTO producto;
                producto = PDAO.buscarProductoPorID(idProducto);
                
                if(producto != null){
                    frmACarrito.cboBuscarNombreP.setSelectedItem(producto.getNombreP());
                    frmACarrito.cboBuscarMarcaP.setSelectedItem(producto.getMarca());
                    frmACarrito.txtBuscarUnidadP.setText(producto.getUnidad());
                    frmACarrito.cboBuscarPrecioP.setSelectedItem(producto.getPrecio());
                    frmACarrito.txtBuscarfechaPedidoP.setText(producto.getFechaPedido());
                    frmACarrito.txtBuscarfechaEntregaP.setText(producto.getFechaEntrega());
                    frmACarrito.txtBuscarTotalP.setText(producto.getTotal());
                } else {
                    JOptionPane.showMessageDialog(null, "PRODUCTO NO ENCONTRADO");
                }
            } catch (SQLException ex) {
                System.err.println();
            }
        }
        if(e.getSource()== frmACarrito.btnAgregadoCarrito){
            PDTO.setNombreP(frmACarrito.cboBuscarNombreP.getSelectedItem().toString());
            PDTO.setMarca(frmACarrito.cboBuscarMarcaP.getSelectedItem().toString());
            PDTO.setUnidad(frmACarrito.txtBuscarUnidadP.getText()); 
            PDTO.setPrecio(frmACarrito.cboBuscarPrecioP.getSelectedItem().toString());
            PDTO.setFechaPedido(frmACarrito.txtBuscarfechaPedidoP.getText());
            PDTO.setFechaEntrega(frmACarrito.txtBuscarfechaEntregaP.getText());
            PDTO.setTotal(frmACarrito.txtBuscarTotalP.getText());
            if(PDAO.ActcarritoProducto(PDTO)){
                JOptionPane.showMessageDialog(null, "PRODUCTO AGREGADO AL CARRITO");
                frmPedido.setVisible(true);
                frmACarrito.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null,"ERROR AL AGREGAR AL CARRITO");
            }
        }
        if(e.getSource()== frmPedido.btnBuscarPedido){
            String idProducto = frmPedido.txtIDproductoPedido.getText();
            List<ProductoDTO> pedido = PDAO.buscarPedido(idProducto);
            
            DefaultTableModel model = (DefaultTableModel) frmPedido.PedidoTabla.getModel();
            model.setRowCount(0);
            
            for(ProductoDTO producto : pedido){
                model.addRow(new Object[]{
                producto.getID_producto(),
                producto.getNombreP(),
                producto.getMarca(),
                producto.getUnidad(),
                producto.getPrecio(),
                producto.getFechaPedido(),
                producto.getFechaEntrega(),
                producto.getTotal()
            });       
    }
         if(pedido.isEmpty()){
        JOptionPane.showMessageDialog(null, "NO SE ENCONTRO EL PEDIDO DEL PRODUCTO");
         }
        }
         if(e.getSource()== frmPedido.btnLimpiarPedido){
             DefaultTableModel model = (DefaultTableModel) frmPedido.PedidoTabla.getModel();
             model.setRowCount(0);
         }
         if(e.getSource()== frmPedido.btnCancelarPedido){
             frmPedido.dispose();
         }
         if(e.getSource()== frmproductos.btnLimpiarProducto){
             limpiarRegistroProducto();
         }
         if(e.getSource()== frmACarrito.btnCancelarCarrito){
             limpiarModificarProducto();
         }
         if(e.getSource()==frmproductos.btnCancelarProducto){
             frmproductos.dispose();
         }
         if(e.getSource()==frmACarrito.btnCancelarCarrito){
             frmACarrito.dispose();
         }    
    }
    private void limpiarRegistroProducto() {
        frmproductos.txtIDproducto.setText(null);
        frmproductos.txtDNIP.setText(null);
        frmproductos.cboNombreP.setSelectedItem(null);
        frmproductos.cbomarca.setSelectedItem(null);
        frmproductos.txtUnidad.setText(null); 
        frmproductos.cboPrecio.setSelectedItem(null);
        frmproductos.txtfechaPedido.setText(null);
        frmproductos.txtfechaEntrega.setText(null);
    }
    public void limpiarModificarProducto(){
        PDTO.setNombreP(frmACarrito.cboBuscarNombreP.getSelectedItem().toString());
            frmACarrito.txtBuscarDNIP.setText(null);
            frmACarrito.cboBuscarNombreP.setSelectedItem(null);
            frmACarrito.cboBuscarMarcaP.setSelectedItem(null);
            frmACarrito.txtBuscarUnidadP.setText(null); 
            frmACarrito.cboBuscarPrecioP.setSelectedItem(null);
            frmACarrito.txtBuscarfechaPedidoP.setText(null);
            frmACarrito.txtBuscarfechaEntregaP.setText(null);
            frmACarrito.txtBuscarTotalP.setText(null); 
    }
}
