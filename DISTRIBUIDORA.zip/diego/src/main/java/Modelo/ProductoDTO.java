
package Modelo;
public class ProductoDTO {
    private String ID_producto;
    private String dni;
    private String nombreP;
    private String marca;
    private String unidad;
    private String precio;
    private String fechaPedido;
    private String fechaEntrega;
    private String total;

    public ProductoDTO() {
    }

    public ProductoDTO(String ID_producto, String dni, String nombreP, String marca, String unidad, String precio, String fechaPedido, String fechaEntrega, String total) {
        this.ID_producto = ID_producto;
        this.dni = dni;
        this.nombreP = nombreP;
        this.marca = marca;
        this.unidad = unidad;
        this.precio = precio;
        this.fechaPedido = fechaPedido;
        this.fechaEntrega = fechaEntrega;
        this.total = total;
    }

    public String getID_producto() {
        return ID_producto;
    }

    public void setID_producto(String ID_producto) {
        this.ID_producto = ID_producto;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombreP() {
        return nombreP;
    }

    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    
}
