
package Modelo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO extends conexion {
        public boolean grabarProductos(ProductoDTO PDTO){
        String sql;
        sql = "insert into Producto values(' " + PDTO.getID_producto() + "', '" + PDTO.getNombreP() + "', "  + "', '" + PDTO.getDni()  + "', ' "
                + "', '" + PDTO.getMarca()  + "', ' " + PDTO.getUnidad() + "', '"
                + " ' " + PDTO.getPrecio() + "', '" + PDTO.getFechaPedido() + " ' "
                + " ' " + PDTO.getFechaEntrega() + "', '" + PDTO.getTotal() + "')";
        
        int mensaje = 0;
        Connection con = null;
        Statement st = null;
        try {
            con = conexion.conectar();
            if(con!=null){  
                JOptionPane.showMessageDialog(null, "CONEXIÓN EXITOSA EN PRODUCTOS" );
            } else {
                JOptionPane.showMessageDialog(null, "NO SE REALIZO LA CONEXIÓN EN PRODUCTOS");
            }
            st = con.createStatement();
            st.executeUpdate(sql);
            return true;
        } catch(SQLException e){
            return false;
        } finally {
            try {
                con.close(); 
            } catch(SQLException e) {
                System.err.println();
            }
        }
    }
        public ProductoDTO buscarProductoPorID(String idProducto) throws SQLException{
            String sql = "SELECT * FROM Producto WHERE ID_productos = '" + idProducto + "'";
            Connection con = null;
            Statement st = null;
            ResultSet rs = null;
            ProductoDTO productos = null;
            
            try{ 
                con = conexion.conectar();  
                st = con.createStatement();
                rs = st.executeQuery(sql);
                
                if(rs.next()){
                    productos = new ProductoDTO();
                    productos.setID_producto(rs.getString("ID_producto"));
                    productos.setDni(rs.getString("dni"));
                    productos.setNombreP(rs.getString("nombreP"));
                    productos.setMarca(rs.getString("Marca"));
                    productos.setPrecio(rs.getString("Precio"));
                    productos.setFechaPedido(rs.getString("FechaPedido"));
                    productos.setFechaEntrega(rs.getString("FechaEntrega"));
                    productos.setTotal(rs.getString("TotalPedido"));          
                } catch(SQLException e){
                        e.printStackTrace();
                }finally{
                    try{
                        if(rs!= null) rs.close();
                        if(st!= null) st.close();
                        if(con!= null) con.close();
                    } catch (SQLException e){
                        e.printStackTrace();
                    }
                }
            return productos;
        }
        public boolean ActcarritoProducto(ProductoDTO PDTO){
            String sql = "UPDATE Productos SET dni = '" +PDTO.getDni()+"',nombreP = '" + PDTO.getNombreP() + "', Marca = '" + PDTO.getMarca() + "'," +
                "Precio = '" + PDTO.getPrecio() + "', FechaPedido = '" + PDTO.getFechaPedido() + "', " +
                    "FechaEntrega = '" + PDTO.getFechaPedido() + "', TotalPedido = '" + PDTO.getTotal() 
                    + "' WHERE id_producto = '" + PDTO.getID_producto() +  "' ";
            Connection con = null;
            Statement st = null;
            
            try { 
                con = conexion.conectar();
                st = con.createStatement();
                int rowsUpdated = st.executeUpdate(sql);
                return rowsUpdated > 0;
            } catch(SQLException e){
                e.printStackTrace();
                return false;
            } finally {
                try {
                    if(st != null) st.close();
                    if(con != null) con.close();
                } catch(SQLException e) {
                    e.printStackTrace();
                }
            }
        }                
        public List<ProductoDTO>buscarPedido(String idProducto){
            String sql = "SELECT * FROM Productos WHERE id_Producto = '" + idProducto + "'";
            Connection con = null;
            Statement st = null;
            ResultSet rs = null;
            List <ProductoDTO> pedido = new ArrayList<>();
            try {
                con = conexion.conectar();
                st = con.createStatement();
                rs = st.executeQuery(sql);
                while(rs.next()){
                    ProductoDTO productos = new ProductoDTO();
                    productos.setID_producto(rs.getString("id_Producto"));
                    productos.setDni(rs.getString("dni"));
                    productos.setNombreP(rs.getString("NombreP"));
                    productos.setMarca(rs.getString("Marca"));
                    productos.setPrecio(rs.getString("Precio"));
                    productos.setFechaPedido(rs.getString("FechaPedido"));
                    productos.setFechaEntrega(rs.getString("FechaEntrega"));
                    productos.setTotal(rs.getString("TotalPedido"));
                    pedido.add(productos);
                }
            } catch(SQLException e){
                e.printStackTrace();
            } finally {
                try {
                    if(rs != null) rs.close();
                    if(st != null) st.close();
                    if(con != null) con.close();
                } catch (SQLException e){
                    e.printStackTrace();
                }                
            }
            return pedido;
        }
    }
