
package Modelo;
public class ClienteDTO {
    private String ID_cliente;
    private String nombreC;
    private String dni;
    private String telefonoM;
    private String correo;
    private String direccion;

    public ClienteDTO() {
    }

    public ClienteDTO(String ID_cliente, String nombreC, String dni, String telefonoM, String correo, String direccion) {
        this.ID_cliente = ID_cliente;
        this.nombreC = nombreC;
        this.dni = dni;
        this.telefonoM = telefonoM;
        this.correo = correo;
        this.direccion = direccion;
    }

    public String getID_cliente() {
        return ID_cliente;
    }

    public void setID_cliente(String ID_cliente) {
        this.ID_cliente = ID_cliente;
    }

    public String getNombreC() {
        return nombreC;
    }

    public void setNombreC(String nombreC) {
        this.nombreC = nombreC;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getTelefonoM() {
        return telefonoM;
    }

    public void setTelefonoM(String telefonoM) {
        this.telefonoM = telefonoM;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
