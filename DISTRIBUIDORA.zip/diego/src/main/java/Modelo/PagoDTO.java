
package Modelo;
public class PagoDTO {
    private String  ID_cliente;
    private String ID_producto;
    private String dni;
    private String nombreC;
    private String nombreP;
    private String medioP;
    private String unidad;
    private String precio;
    private String total;

    public PagoDTO() {
    }

    public PagoDTO(String ID_cliente, String ID_producto, String dni, String nombreC, String nombreP, String medioP, String unidad, String precio, String total) {
        this.ID_cliente = ID_cliente;
        this.ID_producto = ID_producto;
        this.dni = dni;
        this.nombreC = nombreC;
        this.nombreP = nombreP;
        this.medioP = medioP;
        this.unidad = unidad;
        this.precio = precio;
        this.total = total;
    }

    public String getID_cliente() {
        return ID_cliente;
    }

    public void setID_cliente(String ID_cliente) {
        this.ID_cliente = ID_cliente;
    }

    public String getID_producto() {
        return ID_producto;
    }

    public void setID_producto(String ID_producto) {
        this.ID_producto = ID_producto;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombreC() {
        return nombreC;
    }

    public void setNombreC(String nombreC) {
        this.nombreC = nombreC;
    }

    public String getNombreP() {
        return nombreP;
    }

    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public String getMedioP() {
        return medioP;
    }

    public void setMedioP(String medioP) {
        this.medioP = medioP;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }  
}
