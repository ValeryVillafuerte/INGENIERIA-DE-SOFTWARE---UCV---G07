
package Modelo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;

public class PagoDAO extends conexion {
    public boolean grabarPago(PagoDTO PADTO){
        String sql;
        sql = "insert into Pago values ('" + PADTO.getID_cliente() + "', '" + PADTO.getID_producto()
                + "', " + "'" + PADTO.getNombreC() + "', " + PADTO.getNombreP() + "', '" + PADTO.getMedioP() 
                + "', " + "'" + PADTO.getUnidad() + "', " + PADTO.getPrecio() + "', ' " + PADTO.getTotal() + "')";
        int mensaje = 0;
        Connection con = null;
        Statement st = null;
        try {
            con = conexion.conectar();
            if(con!=null){
                JOptionPane.showMessageDialog(null, "CONEXIÓN EXITOSA EN PAGO");
        } else {
                JOptionPane.showMessageDialog(null, "ERROR DE CONEXIÓN EN PAGO");
        }
        st = con.createStatement();
        st.executeUpdate(sql);
        return true; 
    } catch(SQLException e){
        return false;
    } finally {
            try {
                con.close();
            } catch(SQLException e){
                System.err.println();
            }
        }
    }
    public PagoDTO buscarPagoPorID(String idCliente){
        String sql = "SELECT * FROM Pago WHERE id_cliente '" + idCliente + "'";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        PagoDTO pago = null;
        
        try { 
            con = conexion.conectar();
            st = con.createStatement();
            rs = st.executeQuery(sql);
            
            if(rs.next()){
                pago.setID_cliente(rs.getString("id_cliente"));
                pago.setNombreC(rs.getString("nombreC"));
                pago.setNombreP(rs.getString("nombreP"));
                pago.setMedioP(rs.getString("medioP"));
                pago.setUnidad(rs.getString("unidad"));
                pago.setPrecio(rs.getString("precio"));
                pago.setTotal(rs.getString("total"));
            } 
        }catch(SQLException e){
            e.printStackTrace();
        } finally {
            try {
                if(rs!= null) rs.close();
                if(st!=null) st.close();
                if(con!=null) con.close();
            } catch(SQLException e){         
                e.printStackTrace();
            } 
        }
        return pago;
    }
    public boolean ActualizarPago(PagoDTO PADTO){
        String sql = "UPDATE Pago SET nombreC = '" +PADTO.getNombreC() + "', nombreP = '" + PADTO.getNombreP() + "', "+
                "medioP = '" + PADTO.getMedioP() + "', unidad = '" + PADTO.getUnidad() + "', " + "precio = '" +
                PADTO.getPrecio() + "', total = '" + PADTO.getTotal() + "' HERE id_cliente = '" + PADTO.getID_cliente() + "'";
        Connection con = null;
        Statement st = null;
        try {
            con = conexion.conectar();
            st = con.createStatement();
            int rowsUpdated = st.executeUpdate(sql);
            return rowsUpdated > 0;           
        } catch (SQLException e){
            e.printStackTrace();
            return false;
        } finally {
            try {
                if(st !=null) st.close();
                if(con!= null) con.close();
            } catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
    public List<PagoDTO> buscarComprobante(String idCliente){
        String sql = "SELECT * FROM Clientes WHERE dni = '" + idCliente +  "'";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        List<PagoDTO> comprobante = new ArrayList<>();
        
        try { 
            con = conexion.conectar();
            rs = st.executeQuery(sql);
            
            while(rs.next()){
                PagoDTO pago = new PagoDTO();
                pago.setID_cliente(rs.getString("id_cliente"));
                pago.setNombreC(rs.getString("nombreC"));
                pago.setNombreP(rs.getString("nombreP"));
                pago.setMedioP(rs.getString("medioP"));
                pago.setPrecio(rs.getString("precio"));
                pago.setTotal(rs.getString("total"));
            }
        } catch (SQLException e){
            e.printStackTrace();
        } finally { 
            try {
                if(rs!=null) rs.close();
                if(st!=null) st.close();
                if(con!=null) con.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
        return comprobante;
    }
}
