package Modelo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;
 
public class ClienteDAO extends conexion {
    public boolean grabarCliente(ClienteDTO CDTO)
    {
        String sql;
        sql = "insert into clientes values('" + CDTO.getID_cliente() + "', '" + CDTO.getNombreC() + "', "
                + "'" + CDTO.getDni() + "', '" + CDTO.getTelefonoM() + "', '" + CDTO.getCorreo() + "', '" 
                + CDTO.getDireccion() + "')";
        int mensaje = 0;
        Connection con = null;
        Statement st = null;
        try {
            con = conexion.conectar();
            if(con!=null){
                JOptionPane.showMessageDialog(null, "CONEXIÓN EXITOSA");
            }else {
                JOptionPane.showMessageDialog(null, "ERROR CONEXIÓN");
            }
            st = con.createStatement();
            st.executeUpdate(sql);
            return true;
        } catch(SQLException e){
            return false;
        } finally {
            try{
            con.close();
        } catch(SQLException e){
            System.err.println();
        }
        }
    }
    public ClienteDTO buscarClientePorID(String idCliente) 
    {
         String sql = "SELECT * FROM Clientes WHERE id_cliente = '" + idCliente + "'";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        ClienteDTO cliente = null;

        try {
            con = conexion.conectar();
            st = con.createStatement();
            rs = st.executeQuery(sql);

            if (rs.next()) {
                cliente = new ClienteDTO();
                cliente.setID_cliente(rs.getString("ID_cliente"));
                cliente.setNombreC(rs.getString("nombreC"));
                cliente.setDni(rs.getString("dni"));
                cliente.setTelefonoM(rs.getString("telefonoM"));
                cliente.setCorreo(rs.getString("correo"));
                cliente.setDireccion(rs.getString("direccion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
     return cliente;
    }
    public boolean actualizarCliente(ClienteDTO CDTO) 
    {
            String sql = "UPDATE clientes SET nombreC = '" + CDTO.getNombreC() + "', dni = '" + CDTO.getDni() + "', " +
                         "telefonoM = '" + CDTO.getTelefonoM() + "', correo = '" + CDTO.getCorreo() + "', " +
                         "direccion = '" + CDTO.getDireccion() + "' WHERE ID_cliente = '" + CDTO.getID_cliente() + "'";
            Connection con = null;
            Statement st = null;

            try {
                con = conexion.conectar();
                st = con.createStatement();
                int rowsUpdated = st.executeUpdate(sql);

                return rowsUpdated > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            } finally {
                try {
                    if (st != null) st.close();
                    if (con != null) con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
    }
    public List<ClienteDTO> buscarHistorialCliente(String idCliente) {
        String sql = "SELECT * FROM Cliente WHERE dni = '" + idCliente + "'";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        List<ClienteDTO> historial = new ArrayList<>();

        try {
            con = conexion.conectar();
            st = con.createStatement();
            rs = st.executeQuery(sql);

            while (rs.next()) {
                ClienteDTO cliente = new ClienteDTO();
                cliente.setID_cliente(rs.getString("ID_cliente"));
                cliente.setNombreC(rs.getString("nombreC"));
                cliente.setDni(rs.getString("dni"));
                cliente.setTelefonoM(rs.getString("telefonoM"));
                cliente.setCorreo(rs.getString("correo"));
                cliente.setDireccion(rs.getString("direccion"));
                historial.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return historial;
    }
}

